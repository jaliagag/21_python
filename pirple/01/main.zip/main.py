# My favourite song's metadata

"""
Please, replace metadata with your favourite
song - we all know it's Parabol/a by Tool, but
still, you have the option
"""

"""
VARIABLES
"""

Artist = "Tool"
Genre = "Progressive Metal"
SongName = "Parabol/a"
YearReleased = 2001
Album = "Lateralus"
DurationInSeconds = 608
Voice = "Maynard James Keenan"
Bass = "Justin Chancellor"
Guitar = "Adam Jones"
Battery = "Danny Carey"
AlbumCoverArtist = "Alex Grey"
AlbumURL = "https://toolband.com/releases/lateralus/"
Comments = "Best Song Ever. Period"

"""
PRINT SECTION
"""

print("Artist:", Artist)
print("Gender:", Genre)
print("Song name:", SongName)
print("Year released:", YearReleased)
print("Album", Album)
print("Duration in seconds:", DurationInSeconds)
print("Voice", Voice)
print("Bass", Bass)
print("Guitar", Guitar)
print("Battery:", Battery)
print("Cover Artwork by:", AlbumCoverArtist)
print("Album URL:", AlbumURL)
print("Comments:", Comments)

"""
END OF FILE
"""
